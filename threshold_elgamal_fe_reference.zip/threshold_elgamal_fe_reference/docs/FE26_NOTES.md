# Fe 26 Notes

## Toolchain target

This package targets Fe `v26.0.0`.

## Project layout

The scaffold follows the standard Fe ingot shape:

- `fe.toml`
- `src/lib.fe`
- additional modules under `src/`

## Important Fe syntax patterns used here

- `msg` declarations define the public ABI.
- `recv` blocks implement handlers.
- `uses (...)` declares explicit effects.
- `#[event]` marks event structs.
- `#[selector = sol("...")]` pins ABI selectors.

## Why the Fe files are scaffold-level

The public Fe docs give enough information for project structure, message
definitions, `recv` handlers, and testing shape. The main unresolved practical
piece is raw byte-buffer assembly for low-level precompile calls. Because of
that, the Fe modules in this package are intentionally written as:
- concrete where the contract API and storage model are stable,
- pseudocode where raw precompile buffers must be built and dispatched.

That is the right tradeoff for an implementation agent:
- the Python file proves the math,
- the Fe files show what the contract should look like,
- the agent fills in the exact low-level call mechanics against the current
  compiler.

## Recommended implementation tactic

1. Keep all BN254 math validated against the Python vectors.
2. Write exact `staticcall` wrappers to:
   - `0x06` ECADD
   - `0x07` ECMUL
3. Use those wrappers everywhere else.
4. Only after raw EC wrappers work, add proof verification or richer election
   logic.

## Suggested tests

- vector match for generator multiplication
- vector match for one vote encryption
- vector match for aggregated ciphertext
- reject invalid point coordinates
- aggregate tally matches Python reference
- threshold decryption matches Python reference